// ============================================================
// DOZZAA — Naija Ad Manager (Demo PWA)
// All data below is mocked/simulated. No real network calls,
// no real payments. Built as an installable demo experience.
// ============================================================

const NIGERIA_STATES = ["Lagos", "Abuja", "Rivers", "Oyo", "Kano", "Enugu", "Kaduna"];

const PLATFORM_META = {
  meta:    { label: "Meta Ads",    letter: "M", color: "#2a8cf0", bg: "rgba(42,140,240,0.14)" },
  google:  { label: "Google Ads",  letter: "G", color: "#ff5c6e", bg: "rgba(255,92,110,0.14)" },
  tiktok:  { label: "TikTok Ads",  letter: "T", color: "#22d3a8", bg: "rgba(34,211,168,0.14)" },
  twitter: { label: "X (Twitter)", letter: "X", color: "#aebfd6", bg: "rgba(174,191,214,0.14)" },
};

const PIDGIN_TEMPLATES = {
  pidgin: {
    label: "Naija Pidgin English 🇳🇬",
    meta: (kw, type) => `Oya make I tell you something — dis ${kw} no dey carry last! Quality ${type.toLowerCase()} wey go make people dey ask "where you take this?" 🔥 Price dey sweet, delivery dey fast. No sleep on top am — tap "Shop Now" before stock finish!`,
    tiktok: (kw) => `POV: you don see ${kw} for the shop, your money don already enter their account 😂 Hook: "If you no buy this, na you sabi" — Body: show product, show price, show happy customer reviews — CTA: "Click link for checkout now now!"`,
  },
  yoruba: {
    label: "Yoruba infused 💃",
    meta: (kw, type) => `Ę kú àárọ̀! This ${kw} go make you shine gan gan 💃 Original ${type.toLowerCase()} for the discerning customer — fast delivery anywhere for Naija. Bàbá àti Ìyá, oya tap "Shop Now" make you no miss out!`,
    tiktok: (kw) => `Hook: "Ṣe o mọ pé...?" reveal style intro about ${kw} — Body: show the craft/detail close-up with Afrobeat sound — CTA: "Comment 'EMI NI' to claim your discount code!"`,
  },
  igbo: {
    label: "Igbo infused 💰",
    meta: (kw, type) => `Ndewo nu! Anyị nwere ezigbo ${kw} maka gị — ${type} kachasị mma n'ahịa! Ego gị ga-aba uru, ọ bụghị ihe ọzọ. Pịa "Shop Now" ka ị nweta ya tata!`,
    tiktok: (kw) => `Hook: "Ego adịghị ofu n'akpa gị?" — Body: quick value comparison showing why ${kw} pays for itself — CTA: "Send 'NWETA' for the link in bio!"`,
  },
  hausa: {
    label: "Arewa Hausa style ✨",
    meta: (kw, type) => `Sannu! Mun samar da ${kw} mai inganci don kasuwancinku — ${type} mafi kyau a kasuwa! Sayarwa cikin sauri, kudin dawowa idan ba ku gamsu ba. Danna "Shop Now" yanzu!`,
    tiktok: (kw) => `Hook: "Kuna son sauyi a rayuwar ku?" — Body: show product transformation/before-after for ${kw} — CTA: "Aiko 'SO NA' don samun rangwame!"`,
  },
};

// ---------- Mutable in-memory "database" (mock) ----------
const state = {
  loading: true,
  refreshing: false,
  webTab: "dashboard",
  mobileScreen: "home",
  settings: {
    nairaBalance: 482500,
    connections: { meta: true, google: true, tiktok: true, twitter: false },
  },
  campaigns: [
    { id: 1, name: "Ankara Collection Launch", status: "active", overallBudget: 350000, spent: 184200, reach: 1240000, clicks: 18400, conversions: 612, roas: 4.6, durationDays: 14, objective: "Sales", platformDistribution: { meta: 45, google: 20, tiktok: 25, twitter: 10 }, targetStates: ["Lagos", "Abuja", "Rivers"] },
    { id: 2, name: "Detty December Promo", status: "active", overallBudget: 500000, spent: 410500, reach: 2870000, clicks: 41200, conversions: 1340, roas: 5.1, durationDays: 21, objective: "Reach", platformDistribution: { meta: 35, google: 15, tiktok: 40, twitter: 10 }, targetStates: ["Lagos", "Oyo", "Rivers"] },
    { id: 3, name: "Skincare Retargeting", status: "paused", overallBudget: 120000, spent: 96000, reach: 410000, clicks: 6200, conversions: 188, roas: 2.8, durationDays: 7, objective: "Conversions", platformDistribution: { meta: 60, google: 25, tiktok: 10, twitter: 5 }, targetStates: ["Lagos", "Abuja"] },
    { id: 4, name: "Tech Gadgets Flash Sale", status: "active", overallBudget: 275000, spent: 142000, reach: 980000, clicks: 15600, conversions: 402, roas: 3.9, durationDays: 5, objective: "Sales", platformDistribution: { meta: 30, google: 35, tiktok: 25, twitter: 10 }, targetStates: ["Lagos", "Abuja", "Kano", "Enugu"] },
  ],
  socialPosts: [
    { id: 1, content: "New Ankara drop is here, swipe to see the full collection", emoji: "👗", reach: 84200 },
    { id: 2, content: "Owambe season ready outfits, link in bio", emoji: "💃", reach: 132500 },
    { id: 3, content: "Behind the scenes: how we package your order", emoji: "📦", reach: 51300 },
    { id: 4, content: "Customer review compilation, 5 stars all round", emoji: "⭐", reach: 67900 },
    { id: 5, content: "Restock alert: the bestseller is back in stock", emoji: "🛍️", reach: 95400 },
  ],
  recommendations: [
    { id: 1, campaignName: "Ankara Collection Launch", message: "Shift 15% of budget from X to TikTok — TikTok ROAS is outperforming by 2.3x this week.", impact: "+₦42,000 est. monthly value" },
    { id: 2, campaignName: "Detty December Promo", message: "Increase Meta daily spend by ₦8,000 — audience saturation is low and CPM dropped 12%.", impact: "+18% reach potential" },
    { id: 3, campaignName: "Tech Gadgets Flash Sale", message: "Pause Google Search ads on weekdays 1am–5am — near-zero conversions in that window.", impact: "Save ~₦6,500/week" },
  ],
};

let generatedCopy = null;
let toastTimer = null;
let selectedPostToBoost = null;
let boostState = { platforms: ["meta", "tiktok"], dailyBudget: 5000, duration: 7, campaignName: "" };

function triggerToast(msg) {
  clearTimeout(toastTimer);
  let el = document.getElementById("toast");
  if (!el) {
    el = document.createElement("div");
    el.id = "toast";
    el.className = "toast";
    document.body.appendChild(el);
  }
  el.textContent = msg;
  el.style.display = "block";
  toastTimer = setTimeout(() => { el.style.display = "none"; }, 3200);
}

function formatNaira(n) { return "₦" + Number(n || 0).toLocaleString("en-NG"); }
function formatCompact(n) {
  if (n >= 1000000) return (n / 1000000).toFixed(1) + "M";
  if (n >= 1000) return (n / 1000).toFixed(0) + "k";
  return String(n);
}
function uid() { return Math.floor(Math.random() * 1000000); }

function generateLocalizedCopy(keywords, type, dialect) {
  const t = PIDGIN_TEMPLATES[dialect] || PIDGIN_TEMPLATES.pidgin;
  return { meta: { text: t.meta(keywords, type) }, tiktok: { script: t.tiktok(keywords) } };
}

// ============================================================
// Rendering
// ============================================================

const root = document.getElementById("app");

function render() {
  root.innerHTML = `
    ${renderTopbar()}
    <div class="screen">${renderScreen()}</div>
    ${renderTabbar()}
  `;
  bindEvents();
}

function renderTopbar() {
  return `
    <div class="topbar">
      <div class="topbar-left">
        <div class="brand-mark">D</div>
        <div class="brand-text">
          <h1>DOZZAA</h1>
          <p>Naija Ad Manager</p>
        </div>
      </div>
      <div class="balance-chip" id="balance-chip">
        <span class="dot"></span>
        <span>${formatNaira(state.settings.nairaBalance)}</span>
      </div>
    </div>
  `;
}

function renderTabbar() {
  const tabs = [
    { id: "home", label: "Home", ico: "🏠" },
    { id: "feed", label: "Feed", ico: "📣" },
    { id: "boost", label: "Boost", ico: "⚡" },
    { id: "ai", label: "AI Copy", ico: "✨" },
    { id: "campaigns", label: "Ads", ico: "📊" },
  ];
  return `
    <div class="tabbar">
      ${tabs.map(t => `
        <button class="tab-btn ${t.id === "boost" ? "boost" : ""} ${state.mobileScreen === t.id ? "active" : ""}" data-screen="${t.id}">
          <span class="ico">${t.ico}</span>
          <span>${t.label}</span>
        </button>
      `).join("")}
    </div>
  `;
}

function renderScreen() {
  if (state.loading) return renderSkeleton();
  switch (state.mobileScreen) {
    case "home": return renderHome();
    case "feed": return renderFeed();
    case "boost": return renderBoost();
    case "ai": return renderAI();
    case "campaigns": return renderCampaignsScreen();
    default: return renderHome();
  }
}

function renderSkeleton() {
  return `
    <div class="skeleton skeleton-block" style="height:60px;"></div>
    <div class="stat-grid" style="margin-top:14px;">
      ${[1,2,3].map(() => `<div class="skeleton" style="height:70px;"></div>`).join("")}
    </div>
    <div class="skeleton skeleton-block" style="height:160px; margin-top:14px;"></div>
    <div class="skeleton skeleton-block" style="height:160px;"></div>
  `;
}

// ---------------- HOME ----------------
function renderHome() {
  const totalSpend = state.campaigns.reduce((s, c) => s + c.spent, 0);
  const totalReach = state.campaigns.reduce((s, c) => s + c.reach, 0);
  const avgRoas = (state.campaigns.reduce((s, c) => s + c.roas, 0) / state.campaigns.length).toFixed(1);

  return `
    <div class="greeting">
      <h2>Good day, Boss 👋</h2>
      <p>Here's how your campaigns are performing across all platforms.</p>
    </div>

    <div class="banner-card">
      <h3>Naija Marketing Specialist in Your Pocket 🇳🇬</h3>
      <p>Manage Meta, Google, TikTok and X from one central budget. We handle Naira transaction charges and Nigerian geo-targeting automatically.</p>
    </div>

    <div class="section-label">Performance Snapshot</div>
    <div class="stat-grid">
      <div class="stat-card">
        <div class="label">Spend</div>
        <div class="value">₦${formatCompact(totalSpend)}</div>
        <div class="delta up">▲ 12%</div>
      </div>
      <div class="stat-card">
        <div class="label">Reach</div>
        <div class="value">${formatCompact(totalReach)}</div>
        <div class="delta up">▲ 18%</div>
      </div>
      <div class="stat-card">
        <div class="label">ROAS</div>
        <div class="value" style="color:var(--cyan)">${avgRoas}x</div>
        <div class="delta down">▼ 0.2x</div>
      </div>
    </div>

    <div class="section-label">Quick Actions</div>
    <div class="quick-grid">
      <button class="quick-btn" data-action="goto-feed">
        <span style="font-size:18px">📣</span>
        <span>Social Feed</span>
      </button>
      <button class="quick-btn" data-action="goto-ai">
        <span style="font-size:18px">✨</span>
        <span>Naija AI</span>
      </button>
      <button class="quick-btn" data-action="goto-campaigns">
        <span style="font-size:18px">📊</span>
        <span>Campaigns</span>
      </button>
      <button class="quick-btn" data-action="open-topup">
        <span style="font-size:18px">💳</span>
        <span>Naira Topup</span>
      </button>
    </div>

    <div class="section-label">
      <span>Trending Posts to Boost</span>
      <span style="color:var(--cyan); font-weight:700; text-transform:none;">${state.socialPosts.length} ready</span>
    </div>
    <div class="post-row">
      ${state.socialPosts.slice(0, 3).map(post => `
        <div class="post-card" data-action="boost-post" data-post-id="${post.id}">
          <div class="post-thumb">${post.emoji}<div class="overlay">⚡</div></div>
          <div class="post-meta">
            <div class="txt">${post.content}</div>
            <div class="reach">${formatCompact(post.reach)} reach</div>
          </div>
        </div>
      `).join("")}
    </div>

    <div class="section-label">Platform Performance</div>
    ${Object.entries(PLATFORM_META).map(([key, meta]) => {
      const spend = state.campaigns.reduce((s, c) => s + (c.spent * (c.platformDistribution[key] || 0) / 100), 0);
      return `
        <div class="platform-row">
          <div class="left">
            <div class="platform-badge" style="background:${meta.bg}; color:${meta.color};">${meta.letter}</div>
            <div>
              <div class="name">${meta.label}</div>
              <div class="spend">${formatNaira(Math.round(spend))} spent</div>
            </div>
          </div>
          <div class="roas">${avgRoas}x ROAS</div>
        </div>
      `;
    }).join("")}
  `;
}

// ---------------- FEED ----------------
function renderFeed() {
  return `
    <div class="section-label" style="margin-top:0;">Social Feed</div>
    ${state.socialPosts.map(post => `
      <div class="feed-post">
        <div class="feed-post-head">
          <div class="feed-avatar">D</div>
          <div>
            <div class="handle">@successculpture</div>
            <div class="time">Posted recently</div>
          </div>
        </div>
        <div class="feed-media">${post.emoji}</div>
        <div class="feed-body">
          <p>${post.content}</p>
          <div class="feed-stats">
            <span>👁 ${formatCompact(post.reach)}</span>
            <span>❤️ ${formatCompact(Math.round(post.reach * 0.08))}</span>
            <span>💬 ${formatCompact(Math.round(post.reach * 0.01))}</span>
          </div>
          <button class="btn btn-primary" data-action="boost-post" data-post-id="${post.id}">⚡ Boost this Post</button>
        </div>
      </div>
    `).join("")}
  `;
}

// ---------------- BOOST ----------------
function renderBoost() {
  const post = selectedPostToBoost;
  const total = boostState.dailyBudget * boostState.duration;
  const estReach = Math.round(total * 0.14);

  return `
    <div class="section-label" style="margin-top:0;">Boost a Post</div>
    ${post ? `
      <div class="card" style="margin-bottom:16px; display:flex; gap:10px; align-items:center;">
        <div class="post-thumb" style="width:48px;height:48px;border-radius:10px;flex-shrink:0;">${post.emoji}</div>
        <div style="font-size:11.5px; color:var(--text-mid); line-height:1.4;">${post.content}</div>
      </div>
    ` : `
      <div class="card" style="margin-bottom:16px;">
        <p class="muted" style="margin:0; font-size:12px;">No post selected yet — pick a trending post from Home or Feed to boost it, or launch a generic campaign below.</p>
      </div>
    `}

    <div class="field">
      <label>Campaign name</label>
      <input type="text" id="boost-name" placeholder="${post ? 'Boost post #' + post.id : 'e.g. Weekend Flash Sale'}" value="${boostState.campaignName}" />
    </div>

    <div class="field">
      <label>Ad platforms</label>
      <div class="chip-select" id="boost-platforms">
        ${Object.entries(PLATFORM_META).map(([key, meta]) => `
          <button class="chip ${boostState.platforms.includes(key) ? "selected" : ""}" data-platform="${key}">${meta.label}</button>
        `).join("")}
      </div>
    </div>

    <div class="field-row">
      <div class="field">
        <label>Daily budget (₦)</label>
        <input type="number" id="boost-budget" value="${boostState.dailyBudget}" step="500" />
      </div>
      <div class="field">
        <label>Duration (days)</label>
        <input type="number" id="boost-duration" value="${boostState.duration}" min="1" max="60" />
      </div>
    </div>

    <div class="card" style="text-align:center; margin:18px 0;">
      <div class="muted" style="font-size:9.5px; text-transform:uppercase; font-weight:700;">Total consolidated budget</div>
      <div class="mono" style="font-size:18px; font-weight:800; color:var(--emerald); margin:5px 0;">${formatNaira(total)}</div>
      <div class="muted" style="font-size:10.5px;">Est. reach: <strong style="color:var(--text-hi)">~${estReach.toLocaleString()} people</strong></div>
    </div>

    <button class="btn btn-primary" data-action="launch-boost" style="font-size:13px; padding:13px;">🚀 Launch Ad Campaign</button>
  `;
}

// ---------------- AI COPY ----------------
function renderAI() {
  if (!generatedCopy) generatedCopy = generateLocalizedCopy("Designer Ankara Wears", "Fashion and Tailoring", "pidgin");
  return `
    <div class="banner-card" style="margin-bottom:18px;">
      <h3>✨ Pidgin & Local AI Copy Writer</h3>
      <p>Auto-generates high-converting Naija ad copy in the dialect your audience trusts.</p>
    </div>

    <div class="field">
      <label>Product / keywords</label>
      <input type="text" id="ai-keywords" value="Designer Ankara Wears" />
    </div>
    <div class="field">
      <label>Business type</label>
      <input type="text" id="ai-type" value="Fashion and Tailoring" />
    </div>
    <div class="field">
      <label>Dialect style</label>
      <select id="ai-dialect">
        ${Object.entries(PIDGIN_TEMPLATES).map(([key, t]) => `<option value="${key}">${t.label}</option>`).join("")}
      </select>
    </div>

    <button class="btn btn-ghost" data-action="generate-copy" style="margin-bottom:18px;">↻ Regenerate</button>

    <div class="copy-block">
      <span class="tag" style="color:var(--pink);">Instagram Post Draft</span>
      <p style="font-style:italic;">"${generatedCopy.meta.text}"</p>
    </div>

    <div class="copy-block mono">
      <span class="tag" style="color:var(--cyan-dim);">TikTok Video Hook</span>
      <p>${generatedCopy.tiktok.script}</p>
    </div>

    <button class="btn btn-ghost" data-action="copy-text">📋 Copy Instagram Post Text</button>
  `;
}

// ---------------- CAMPAIGNS ----------------
function renderCampaignsScreen() {
  return `
    <div class="flex-between" style="margin-bottom:14px;">
      <div class="section-label" style="margin:0;">Consolidated Campaigns</div>
    </div>
    <div class="fab-row">
      <button class="fab" data-action="open-new-campaign">+ New Campaign</button>
    </div>
    ${state.campaigns.map(camp => renderCampaignCard(camp)).join("")}
  `;
}

function renderCampaignCard(camp) {
  const pct = Math.min(100, Math.round((camp.spent / camp.overallBudget) * 100));
  return `
    <div class="campaign-card">
      <div class="campaign-top">
        <div class="name">${camp.name}</div>
        <span class="status-pill ${camp.status}">${camp.status}</span>
      </div>
      <div class="campaign-mid">
        <span>Budget: ${formatNaira(camp.overallBudget)}</span>
        <span class="roas">${camp.roas}x ROAS</span>
      </div>
      <div class="campaign-bar"><div class="campaign-bar-fill" style="width:${pct}%"></div></div>
      <div class="campaign-actions">
        <button class="icon-btn optimize" data-action="optimize-campaign" data-id="${camp.id}">✨ Optimize ROAS</button>
        <button class="icon-btn" data-action="${camp.status === 'active' ? 'pause-campaign' : 'resume-campaign'}" data-id="${camp.id}">${camp.status === 'active' ? '⏸ Pause' : '▶ Resume'}</button>
        <button class="icon-btn danger" data-action="delete-campaign" data-id="${camp.id}">🗑</button>
      </div>
    </div>
  `;
}

// ---------------- MODALS ----------------
function renderTopupModal() {
  return `
    <div class="modal-overlay center" id="topup-overlay">
      <div class="modal-sheet">
        <div class="modal-head">
          <h3>💳 Naira Top-up (Demo)</h3>
          <button class="modal-close" data-action="close-modal">&times;</button>
        </div>
        <p class="muted" style="font-size:11.5px; margin-top:-6px; margin-bottom:16px; line-height:1.5;">
          This is a simulated checkout for demo purposes — no real payment provider is connected and no money will be charged.
        </p>
        <div class="field">
          <label>Amount (₦)</label>
          <input type="number" id="topup-amount" value="20000" step="1000" min="500" />
        </div>
        <div class="chip-select" style="margin-bottom:16px;">
          ${[10000, 20000, 50000, 100000].map(v => `<button class="chip" data-topup-quick="${v}">₦${v.toLocaleString()}</button>`).join("")}
        </div>
        <button class="btn btn-emerald" data-action="confirm-topup">Simulate Payment</button>
      </div>
    </div>
  `;
}

function renderNewCampaignModal() {
  return `
    <div class="modal-overlay" id="campaign-overlay">
      <div class="modal-sheet">
        <div class="modal-head">
          <h3>New Campaign</h3>
          <button class="modal-close" data-action="close-modal">&times;</button>
        </div>
        <div class="field">
          <label>Campaign name</label>
          <input type="text" id="new-camp-name" placeholder="e.g. New Year Sale Push" />
        </div>
        <div class="field">
          <label>Objective</label>
          <select id="new-camp-objective">
            <option>Sales</option>
            <option>Reach</option>
            <option>Conversions</option>
            <option>Brand Awareness</option>
          </select>
        </div>
        <div class="field-row">
          <div class="field">
            <label>Overall budget (₦)</label>
            <input type="number" id="new-camp-budget" value="100000" step="5000" />
          </div>
          <div class="field">
            <label>Duration (days)</label>
            <input type="number" id="new-camp-duration" value="7" min="1" max="90" />
          </div>
        </div>
        <div class="field">
          <label>Target states</label>
          <div class="chip-select" id="new-camp-states">
            ${NIGERIA_STATES.map(s => `<button class="chip ${s === "Lagos" ? "selected" : ""}" data-state="${s}">${s}</button>`).join("")}
          </div>
        </div>
        <button class="btn btn-primary" data-action="create-campaign" style="margin-top:8px;">Launch Campaign</button>
      </div>
    </div>
  `;
}

let activeModal = null;
let newCampaignStates = ["Lagos"];

function openModal(name) {
  activeModal = name;
  const container = document.createElement("div");
  container.id = "modal-root";
  container.innerHTML = name === "topup" ? renderTopupModal() : renderNewCampaignModal();
  document.body.appendChild(container);
  bindModalEvents();
}

function closeModal() {
  activeModal = null;
  const el = document.getElementById("modal-root");
  if (el) el.remove();
}

function bindModalEvents() {
  const modalRoot = document.getElementById("modal-root");
  if (!modalRoot) return;

  modalRoot.querySelectorAll('[data-action="close-modal"]').forEach(b =>
    b.addEventListener("click", closeModal)
  );
  const overlay = modalRoot.querySelector(".modal-overlay");
  if (overlay) {
    overlay.addEventListener("click", (e) => { if (e.target === overlay) closeModal(); });
  }

  if (activeModal === "topup") {
    modalRoot.querySelectorAll("[data-topup-quick]").forEach(b =>
      b.addEventListener("click", () => {
        document.getElementById("topup-amount").value = b.dataset.topupQuick;
      })
    );
    const confirmBtn = modalRoot.querySelector('[data-action="confirm-topup"]');
    if (confirmBtn) confirmBtn.addEventListener("click", () => {
      const amt = Number(document.getElementById("topup-amount").value) || 0;
      if (amt <= 0) { triggerToast("Enter a valid amount"); return; }
      confirmBtn.textContent = "Processing...";
      confirmBtn.disabled = true;
      setTimeout(() => {
        state.settings.nairaBalance += amt;
        closeModal();
        triggerToast(`Simulated top-up successful: ${formatNaira(amt)} added`);
        render();
      }, 900);
    });
  }

  if (activeModal === "campaign") {
    modalRoot.querySelectorAll("[data-state]").forEach(b =>
      b.addEventListener("click", () => {
        const s = b.dataset.state;
        if (newCampaignStates.includes(s)) {
          newCampaignStates = newCampaignStates.filter(x => x !== s);
        } else {
          newCampaignStates.push(s);
        }
        b.classList.toggle("selected");
      })
    );
    const createBtn = modalRoot.querySelector('[data-action="create-campaign"]');
    if (createBtn) createBtn.addEventListener("click", () => {
      const name = document.getElementById("new-camp-name").value.trim();
      if (!name) { triggerToast("Give your campaign a name"); return; }
      const budget = Number(document.getElementById("new-camp-budget").value) || 50000;
      const duration = Number(document.getElementById("new-camp-duration").value) || 7;
      const objective = document.getElementById("new-camp-objective").value;
      state.campaigns.unshift({
        id: uid(), name, status: "active", overallBudget: budget, spent: 0,
        reach: 0, clicks: 0, conversions: 0, roas: 1.0, durationDays: duration,
        objective, platformDistribution: { meta: 40, google: 20, tiktok: 30, twitter: 10 },
        targetStates: newCampaignStates.length ? newCampaignStates : ["Lagos"],
      });
      newCampaignStates = ["Lagos"];
      closeModal();
      triggerToast(`Campaign "${name}" launched`);
      render();
    });
  }
}

// ============================================================
// Event binding for the main screen
// ============================================================
function bindEvents() {
  document.querySelectorAll(".tab-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      state.mobileScreen = btn.dataset.screen;
      render();
    });
  });

  root.querySelectorAll("[data-action]").forEach(el => {
    el.addEventListener("click", () => handleAction(el.dataset.action, el));
  });

  // Boost screen interactive bits
  const platformWrap = document.getElementById("boost-platforms");
  if (platformWrap) {
    platformWrap.querySelectorAll(".chip").forEach(chip => {
      chip.addEventListener("click", () => {
        const p = chip.dataset.platform;
        if (boostState.platforms.includes(p)) {
          boostState.platforms = boostState.platforms.filter(x => x !== p);
        } else {
          boostState.platforms.push(p);
        }
        chip.classList.toggle("selected");
      });
    });
  }
  const boostBudgetInput = document.getElementById("boost-budget");
  if (boostBudgetInput) boostBudgetInput.addEventListener("input", (e) => {
    boostState.dailyBudget = Number(e.target.value) || 0;
    refreshBoostSummary();
  });
  const boostDurationInput = document.getElementById("boost-duration");
  if (boostDurationInput) boostDurationInput.addEventListener("input", (e) => {
    boostState.duration = Number(e.target.value) || 0;
    refreshBoostSummary();
  });
  const boostNameInput = document.getElementById("boost-name");
  if (boostNameInput) boostNameInput.addEventListener("input", (e) => {
    boostState.campaignName = e.target.value;
  });

  // AI screen live regen on dialect change
  const dialectSelect = document.getElementById("ai-dialect");
  if (dialectSelect) dialectSelect.addEventListener("change", regenerateCopy);
}

function refreshBoostSummary() {
  const total = boostState.dailyBudget * boostState.duration;
  const estReach = Math.round(total * 0.14);
  const totalEl = document.querySelector(".card .mono");
  if (totalEl) totalEl.textContent = formatNaira(total);
  const reachEls = document.querySelectorAll(".card strong");
  if (reachEls[0]) reachEls[0].textContent = `~${estReach.toLocaleString()} people`;
}

function regenerateCopy() {
  const kw = document.getElementById("ai-keywords")?.value || "Designer Ankara Wears";
  const type = document.getElementById("ai-type")?.value || "Fashion and Tailoring";
  const dialect = document.getElementById("ai-dialect")?.value || "pidgin";
  generatedCopy = generateLocalizedCopy(kw, type, dialect);
  render();
}

function handleAction(action, el) {
  switch (action) {
    case "goto-feed": state.mobileScreen = "feed"; render(); break;
    case "goto-ai": state.mobileScreen = "ai"; render(); break;
    case "goto-campaigns": state.mobileScreen = "campaigns"; render(); break;
    case "open-topup": openModal("topup"); break;
    case "open-new-campaign": openModal("campaign"); break;

    case "boost-post": {
      const postId = Number(el.dataset.postId);
      selectedPostToBoost = state.socialPosts.find(p => p.id === postId) || null;
      boostState.campaignName = selectedPostToBoost ? `Boost post #${selectedPostToBoost.id}` : "";
      state.mobileScreen = "boost";
      render();
      triggerToast("Post loaded into Boost screen");
      break;
    }

    case "launch-boost": {
      if (boostState.platforms.length === 0) { triggerToast("Pick at least one platform"); return; }
      const total = boostState.dailyBudget * boostState.duration;
      if (total > state.settings.nairaBalance) { triggerToast("Insufficient balance — try Naira Topup"); return; }
      state.settings.nairaBalance -= total;
      const name = boostState.campaignName || (selectedPostToBoost ? `Boost post #${selectedPostToBoost.id}` : "New Boost Campaign");
      state.campaigns.unshift({
        id: uid(), name, status: "active", overallBudget: total, spent: Math.round(total * 0.05),
        reach: Math.round(total * 0.1), clicks: Math.round(total * 0.005), conversions: Math.round(total * 0.0008),
        roas: 1.2, durationDays: boostState.duration, objective: "Boost",
        platformDistribution: Object.fromEntries(boostState.platforms.map(p => [p, Math.round(100 / boostState.platforms.length)])),
        targetStates: ["Lagos"],
      });
      selectedPostToBoost = null;
      boostState = { platforms: ["meta", "tiktok"], dailyBudget: 5000, duration: 7, campaignName: "" };
      state.mobileScreen = "campaigns";
      render();
      triggerToast(`🚀 Campaign "${name}" launched`);
      break;
    }

    case "generate-copy": regenerateCopy(); break;
    case "copy-text": {
      const text = generatedCopy?.meta?.text || "";
      navigator.clipboard?.writeText(text).then(
        () => triggerToast("Copied to clipboard!"),
        () => triggerToast("Couldn't copy — select text manually")
      );
      break;
    }

    case "optimize-campaign": {
      const id = Number(el.dataset.id);
      const camp = state.campaigns.find(c => c.id === id);
      if (camp) {
        camp.roas = +(camp.roas + 0.3).toFixed(1);
        triggerToast(`AI rebalanced budget — ${camp.name} ROAS now ${camp.roas}x`);
        render();
      }
      break;
    }
    case "pause-campaign": {
      const camp = state.campaigns.find(c => c.id === Number(el.dataset.id));
      if (camp) { camp.status = "paused"; triggerToast(`${camp.name} paused`); render(); }
      break;
    }
    case "resume-campaign": {
      const camp = state.campaigns.find(c => c.id === Number(el.dataset.id));
      if (camp) { camp.status = "active"; triggerToast(`${camp.name} resumed`); render(); }
      break;
    }
    case "delete-campaign": {
      const id = Number(el.dataset.id);
      state.campaigns = state.campaigns.filter(c => c.id !== id);
      triggerToast("Campaign deleted");
      render();
      break;
    }
  }
}

// ============================================================
// PWA install prompt handling
// ============================================================
let deferredInstallEvent = null;

window.addEventListener("beforeinstallprompt", (e) => {
  e.preventDefault();
  deferredInstallEvent = e;
  const toast = document.getElementById("install-toast");
  if (toast && !sessionStorage.getItem("dismissedInstall")) {
    toast.classList.remove("hidden");
  }
});

function setupInstallToast() {
  const dismiss = document.getElementById("install-dismiss");
  const action = document.getElementById("install-action");
  const toast = document.getElementById("install-toast");
  if (dismiss) dismiss.addEventListener("click", () => {
    toast.classList.add("hidden");
    sessionStorage.setItem("dismissedInstall", "1");
  });
  if (action) action.addEventListener("click", async () => {
    if (deferredInstallEvent) {
      deferredInstallEvent.prompt();
      await deferredInstallEvent.userChoice;
      deferredInstallEvent = null;
    }
    toast.classList.add("hidden");
  });
}

function setupDemoBanner() {
  const banner = document.getElementById("demo-banner");
  const closeBtn = document.getElementById("demo-banner-close");
  if (sessionStorage.getItem("dismissedDemoBanner")) {
    banner.style.display = "none";
    return;
  }
  if (closeBtn) closeBtn.addEventListener("click", () => {
    banner.style.display = "none";
    sessionStorage.setItem("dismissedDemoBanner", "1");
  });
  setTimeout(() => { if (banner) banner.style.display = "none"; }, 6000);
}

// ============================================================
// Boot
// ============================================================
function boot() {
  setupInstallToast();
  setupDemoBanner();

  state.loading = true;
  render();

  setTimeout(() => {
    state.loading = false;
    render();
  }, 700);

  if ("serviceWorker" in navigator) {
    window.addEventListener("load", () => {
      navigator.serviceWorker.register("sw.js").catch(() => {});
    });
  }
}

document.addEventListener("DOMContentLoaded", boot);
